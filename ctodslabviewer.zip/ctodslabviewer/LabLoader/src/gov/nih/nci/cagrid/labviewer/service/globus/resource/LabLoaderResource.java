package gov.nih.nci.cagrid.labviewer.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this LabLoaderResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class LabLoaderResource extends BaseResourceBase {



}
