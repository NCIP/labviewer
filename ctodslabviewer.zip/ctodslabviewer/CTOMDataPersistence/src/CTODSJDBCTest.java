import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CTODSJDBCTest
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Connection con = null;
	    
		String fDriverName="oracle.jdbc.driver.OracleDriver";
		String fDbName="jdbc:oracle:thin:@cbiodb30.nci.nih.gov:1521:cccqa";
		//String fDbName="jdbc:oracle:thin:@localhost:1521:xe";
		String fUserName="caxchange";
		String fPassword="caxchange";

	    try
	    {
	       Class.forName(fDriverName).newInstance();
	    }
	    catch (Exception ex)
	    {
	        System.err.println("Check classpath. Cannot load db driver: " + fDriverName);
	        return;
	    }

	    try
	    {
	    	con = DriverManager.getConnection(fDbName, fUserName, fPassword);
	    	
	    	if (con != null)
		    {
		    	PreparedStatement ps = null;
				ResultSet rs = null;
				Long id = null;;
				
				ps = con.prepareStatement("select p.ID from protocol p, identifier ii where p.ID = ii.PROTOCOL_ID and ii.extension=?");
				ps.setString(1, "04_C_0121");
				
				rs = ps.executeQuery();

				// If it exists get the ID
				if (rs.next())
				{
					id = rs.getLong(1);
					System.out.println("The protocol id is " + id);
				}
		    }
	    }
	    catch (SQLException e)
	    {
	        System.err.println( "Driver loaded, but cannot connect to db: " + fDbName);
	    }
	    
	}

}
