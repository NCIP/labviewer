package gov.nih.nci.ccts.grid.service.globus.resource;

import org.globus.wsrf.InvalidResourceKeyException;
import org.globus.wsrf.NoSuchResourceException;
import org.globus.wsrf.ResourceException;
import org.globus.wsrf.ResourceKey;


/** 
 * The implementation of this RegistrationConsumerResource type.
 * 
 * @created by Introduce Toolkit version 1.2
 * 
 */
public class RegistrationConsumerResource extends RegistrationConsumerResourceBase {

}
