package gov.nih.nci.cagrid.labviewer.grid.service.globus.resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/** 
 * The implementation of this StudyLookupServiceResource type.
 * 
 * @created by Introduce Toolkit version 1.1
 * 
 */
public class StudyLookupServiceResource extends BaseResourceBase {



}
