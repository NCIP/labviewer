package gov.nih.nci.ctom.ctlab.persistence;

public class LabViewerDAOSupport extends org.springframework.orm.hibernate3.support.HibernateDaoSupport
{

}
